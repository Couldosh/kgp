<?php ob_start(); ?> 
		<div id="galerie">
			<a href="images/galerie/12.jpg"><img class="photogalerie" src="images/galerie/small_12.jpg" alt="12"></a>
			<a href="images/galerie/13.jpg"><img class="photogalerie" src="images/galerie/small_13.jpg" alt="13"></a>
			<a href="images/galerie/10.jpg"><img class="photogalerie" src="images/galerie/small_10.jpg" alt="10"></a>
			<a href="images/galerie/46.jpg"><img class="photogalerie" src="images/galerie/small_46.jpg" alt="46"></a>
			<a href="images/galerie/48.jpg"><img class="photogalerie" src="images/galerie/small_48.jpg" alt="48"></a>
			<a href="images/galerie/49.jpg"><img class="photogalerie" src="images/galerie/small_49.jpg" alt="49"></a>
			<a href="images/galerie/50.jpg"><img class="photogalerie" src="images/galerie/small_50.jpg" alt="50"></a>
			<a href="images/galerie/pirate.jpg"><img class="photogalerie" src="images/galerie/small_pirate.jpg" alt="pirate"></a>
			<a href="images/galerie/vaiana.jpg"><img class="photogalerie" src="images/galerie/small_vaiana.jpg" alt="vaiana"></a>
			<a href="images/moyen/avengers.jpg"><img class="photogalerie" src="images/moyen/small_avengers.jpg" alt="Chateau avengers"></a>
			<a href="images/moyen/mickey.jpg"><img class="photogalerie" src="images/moyen/small_mickey.jpg" alt="Chateau mickey"></a>
			<a href="images/moyen/orange.jpg"><img class="photogalerie" src="images/moyen/small_orange.jpg" alt="Chateau orange"></a>
			<a href="images/moyen/disney.jpg"><img class="photogalerie" src="images/moyen/small_disney.jpg" alt="Chateau disney"></a>
			<a href="images/grand/cars.jpg"><img class="photogalerie" src="images/grand/small_cars.jpg" alt="Chateau cars"></a>
			<a href="images/grand/truck.jpg"><img class="photogalerie" src="images/grand/small_truck.jpg" alt="Chateau truck"></a>
			<a href="images/grand/carosse.jpg"><img class="photogalerie" src="images/grand/small_carosse.jpg" alt="Chateau carosse"></a>
		</div>
<?php $content = ob_get_clean(); ?> 
<?php include 'view/layout.php';?>


