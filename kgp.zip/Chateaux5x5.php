<?php ob_start(); ?> 
		<table>
			<tr>
				<th></th>
				<th>1/2 journée</th>
				<th>Journée complète</th>
				<th>Forfait Week-End<br>(Samedi 10h jusqu'à Dimanche 16h)</th>
			</tr>
			<tr>
				<td><p class="ptable">Avengers</p><a href="images/moyen/avengers.jpg"><img src="images/moyen/small_avengers.jpg" alt="Chateau avengers"></a></td>
				<td>28 000 TTC</td>
				<td>34 500 TTC</td>
				<td>51 750 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Reine des Neiges</p><a href="images/moyen/reineDN.jpg"><img src="images/moyen/small_reineDN.jpg" alt="Chateau Reine des neiges"></a></td>
				<td>28 000 TTC</td>
				<td>34 500 TTC</td>
				<td>51 750 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Minions</p><a href="images/moyen/minions.png"><img src="images/moyen/small_minions.jpg" alt="Chateau minions"></a></td>
				<td>28 000 TTC</td>
				<td>34 500 TTC</td>
				<td>51 750 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Minnie Mickey</p><a href="images/moyen/mickey.jpg"><img src="images/moyen/small_mickey.jpg" alt="Chateau mickey"></a></td>
				<td>22 000 TTC</td>
				<td>28 000 TTC</td>
				<td>42 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Orange</p><a href="images/moyen/orange.jpg"><img src="images/moyen/small_orange.jpg" alt="Chateau orange"></a></td>
				<td>22 000 TTC</td>
				<td>28 000 TTC</td>
				<td>42 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Disney</p><a href="images/moyen/disney.jpg"><img src="images/moyen/small_disney.jpg" alt="Chateau disney"></a></td>
				<td>22 000 TTC</td>
				<td>28 000 TTC</td>
				<td>42 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Escalade</p><a href="images/moyen/escalade.jpg"><img src="images/moyen/small_escalade.jpg" alt="Chateau escalade"></a></td>
				<td>22 000 TTC</td>
				<td>28 000 TTC</td>
				<td>42 000 TTC</td>
			</tr>
		</table>
<?php $content = ob_get_clean(); ?> 
<?php include 'view/layout.php';?>

