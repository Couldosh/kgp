<?php ob_start(); ?> 				
		<table>
			<tr>
				<th></th>
				<th>1/2 journée</th>
				<th>Journée complète</th>
				<th>Forfait Week-End<br>(Samedi 10h jusqu'à Dimanche 16h)</th>
			</tr>
			<tr>
				<td><p class="ptable">Vaiana</p><a href="images/grand/vaiana.jpg"><img src="images/grand/small_vaiana.jpg" alt="Chateau vaiana"></a></td>
				<td>43 100 TTC</td>
				<td>48 600 TTC</td>
				<td>72 900 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Camion de pompier</p><a href="images/grand/pompier.jpg"><img src="images/grand/small_pompier.jpg" alt="Chateau vaiana"></a></td>
				<td>50 000 TTC</td>
				<td>55 000 TTC</td>
				<td>82 500 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Bateau pirate</p><a href="images/grand/pirate.jpg"><img src="images/grand/small_pirate.jpg" alt="Chateau pirate"></a></td>
				<td>43 100 TTC</td>
				<td>48 600 TTC</td>
				<td>72 900 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Cars</p><a href="images/grand/cars.jpg"><img src="images/grand/small_cars.jpg" alt="Chateau cars"></a></td>
				<td>35 500 TTC</td>
				<td>42 000 TTC</td>
				<td>63 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Monster Truck</p><a href="images/grand/truck.jpg"><img src="images/grand/small_truck.jpg" alt="Chateau truck"></a></td>
				<td>35 500 TTC</td>
				<td>42 000 TTC</td>
				<td>63 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Carrosse de princesse</p><a href="images/grand/carosse.jpg"><img src="images/grand/small_carosse.jpg" alt="Chateau carosse"></a></td>
				<td>35 500 TTC</td>
				<td>42 000 TTC</td>
				<td>63 000 TTC</td>
			</tr>
			
			
		</table>
<?php $content = ob_get_clean(); ?> 
<?php include 'view/layout.php';?>
