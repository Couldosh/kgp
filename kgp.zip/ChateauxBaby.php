<?php ob_start(); ?> 
				
		<table>
			<tr>
				<th></th>
				<th>1/2 journée</th>
				<th>Journée complète</th>
				<th>Forfait Week-End<br>(Samedi 10h jusqu'à Dimanche 16h)</th>
			</tr>
			<tr>
				<td><p class="ptable">Baby Aquarium</p><a href="images/baby/aquarium.jpg"><img src="images/baby/small_aquarium.jpg" alt="Chateau baby aquarium"></a></td>
				<td>28 000 TTC</td>
				<td>34 500 TTC</td>
				<td>51 750 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Baby Safari</p><a href="images/baby/safari.jpg"><img src="images/baby/small_safari.jpg" alt="Chateau baby safari"></a></td>
				<td>28 000 TTC</td>
				<td>34 500 TTC</td>
				<td>51 750 TTC</td>
			</tr>
		</table>

<?php $content = ob_get_clean(); ?> 
<?php include 'view/layout.php';?>

