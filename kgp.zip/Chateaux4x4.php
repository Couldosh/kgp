<?php ob_start(); ?> 
		<table>
			<tr>
				<th></th>
				<th>1/2 journée</th>
				<th>Journée complète</th>
				<th>Forfait Week-End<br>(Samedi 10h jusqu'à Dimanche 16h)</th>
			</tr>
			<tr>
				<td><p class="ptable">Etoilé</p><a href="images/petit/etoile.jpg"><img src="images/petit/small_etoile.jpg" alt="Chateau étoilé"></a></td>
				<td>16 500 TTC</td>
				<td>22 000 TTC</td>
				<td>33 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Rio</p><a href="images/petit/rio.jpg"><img src="images/petit/small_rio.jpg" alt="Chateau rio"></a></td>
				<td>16 500 TTC</td>
				<td>22 000 TTC</td>
				<td>33 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Océan</p><a href="images/petit/océan.jpg"><img src="images/petit/small_océan.jpg" alt="Chateau océan"></a></td>
				<td>16 500 TTC</td>
				<td>22 000 TTC</td>
				<td>33 000 TTC</td>
			</tr>
			<tr>
				<td><p class="ptable">Clochette</p><a href="images/petit/clochette.jpg"><img src="images/petit/small_clochette.jpg" alt="Chateau clochette"></a></td>
				<td>16 500 TTC</td>
				<td>22 000 TTC</td>
				<td>33 000 TTC</td>
			</tr>
		</table>
<?php $content = ob_get_clean(); ?> 
<?php include 'view/layout.php';?>
