<?php ob_start(); ?> 
			<div style="margin-bottom: 3.2%">
				<div>
					<p>
						Kids Gonflables Party vous propose à la location de nombreaux châteaux gonflables pour tout vos anniversaires, mariages, kermesses et comités d'entreprise! <br>
						Nous pouvons livrer nos châteaux n'importe où sur la Grande Terre!
					</p>
					
				</div>
				<div id="Nouveauté">
					<h1 style="background-color: transparent;">Nouveauté !</h1>
					<p style="background-color: transparent;">Nous vous proposons un nouveau forfait pour le Week-End! <br>Dorénavant, vous pourrez louer votre château à partir du Samedi à 10h jusqu'au Dimanche à 16h</p>

				</div>
				<center>
					<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FKidsGonflables%2F&tabs=events%2Ctimeline&width=500&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="500" height="500" style="border:none;overflow:hidden;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
				</center>
				
				
				
				 	
			<table>
				<tr>
					<td>
						<img src="images/vaiana.png" alt="Chateau vaiana">
					</td>
					<td>
						<img src="images/minions.png" alt="Chateau minions">
					</td>
				</tr>
			</table>
		</div>

<?php $content = ob_get_clean(); ?> 
<?php include 'view/layout.php';?>

